export default function installAsJQueryPlugin($: any): void;
